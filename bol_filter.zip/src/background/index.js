// Background entry point for future network/data work.
chrome.runtime.onInstalled.addListener(() => {
  console.info("GlazenBol installed");
});
